import js from '@eslint/js';
import globals from 'globals';
import reactHooks from 'eslint-plugin-react-hooks';
import reactRefresh from 'eslint-plugin-react-refresh';

// ESLint-ийн тохиргоо (flat config): https://eslint.org/docs/latest/use/configure/
// Даалгавраар илгээх таны код ESLint-ийг ямар нэг алдаа, санамжгүйгээр (warnings)
// давсан байх ёстой.
export default [
  { ignores: ['dist'] },
  {
    files: ['**/*.{js,jsx}'],
    languageOptions: {
      ecmaVersion: 'latest',
      sourceType: 'module',
      globals: globals.browser,
      parserOptions: { ecmaFeatures: { jsx: true } },
    },
    plugins: {
      'react-hooks': reactHooks,
      'react-refresh': reactRefresh,
    },
    rules: {
      ...js.configs.recommended.rules,
      // Hooks-ийн дүрэм: Hook-ийг зөвхөн компонентын дээд түвшинд дуудах,
      // useEffect-ийн dependency жагсаалтыг бүрэн бичих гэх мэт.
      ...reactHooks.configs.recommended.rules,
      // Нэг файлаас зөвхөн компонент экспортлох (Vite-ийн хурдан шинэчлэлтэд хэрэгтэй).
      'react-refresh/only-export-components': 'warn',
      'no-console': 'off',
    },
  },
  {
    // Node.js дээр ажилладаг файлууд (веб сервер, өгөгдлийн сан, тохиргоо, тест).
    files: [
      'webServer.js',
      'loadDatabase.js',
      'vite.config.js',
      'eslint.config.js',
      'schema/**/*.js',
      'test/**/*.js',
    ],
    languageOptions: {
      globals: globals.node,
    },
  },
  {
    // Mocha тест (describe, it гэх мэт глобал функцууд).
    files: ['test/**/*.js'],
    languageOptions: {
      globals: { ...globals.node, ...globals.mocha },
    },
  },
];
