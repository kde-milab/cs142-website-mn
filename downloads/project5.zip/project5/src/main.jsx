import { StrictMode } from 'react';
import { createRoot } from 'react-dom/client';

import PhotoShare from './photoShare';

// index.html доторх id="photoshareapp" div дээр React-ийн root үүсгээд
// PhotoShare компонентийг түүн дотор рендерлэнэ.
// StrictMode нь хөгжүүлэлтийн горимд алдааг эрт илрүүлэхэд тусалдаг.
const root = createRoot(document.getElementById('photoshareapp'));
root.render(
  <StrictMode>
    <PhotoShare />
  </StrictMode>
);
