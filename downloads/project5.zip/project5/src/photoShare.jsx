import { BrowserRouter, Routes, Route, Outlet } from 'react-router';
import { Grid, Typography, Paper } from '@mui/material';

import './styles/main.css';
import TopBar from './components/TopBar/TopBar';
import UserDetail from './components/UserDetail/UserDetail';
import UserList from './components/UserList/UserList';
import UserPhotos from './components/UserPhotos/UserPhotos';

/**
 * Аппын хүрээ (layout): дээд талд TopBar, зүүн талд хэрэглэгчдийн жагсаалт,
 * баруун талд үндсэн контент. URL-д тохирох дэд замын (nested route)
 * компонент <Outlet /> байрлалд рендерлэгдэнэ.
 */
function PhotoShareLayout() {
  return (
    <>
      <TopBar />
      <div className="icsi301-main-topbar-buffer" />
      <Grid container spacing={2}>
        <Grid size={{ xs: 12, sm: 3 }}>
          <Paper className="icsi301-main-grid-item">
            <UserList />
          </Paper>
        </Grid>
        <Grid size={{ xs: 12, sm: 9 }}>
          <Paper className="icsi301-main-grid-item">
            <Outlet />
          </Paper>
        </Grid>
      </Grid>
    </>
  );
}

/**
 * Нүүр хуудсанд (/) харуулах түр угтах текст.
 */
function Welcome() {
  return (
    <Typography variant="body1">
      Фото хуваалцах аппад тавтай морил! Энэ{' '}
      <a href="https://mui.com/material-ui/react-paper/">Paper</a> компонент
      аппын үндсэн контентыг харуулна. Мөн{' '}
      <a href="https://mui.com/material-ui/react-grid/">Grid</a> компонентын{' '}
      {'size={{ xs: 12, sm: 9 }}'} шинж нь цонхны 9/12 хэсгийг эзлэхээр
      (responsive) дэлгэцлүүлнэ. <code>&lt;Routes&gt;</code> компонент нь URL-д
      тохирох <code>&lt;Route&gt;</code>-ийг сонгож, түүний компонентыг{' '}
      <code>&lt;Outlet /&gt;</code> байрлалд рендерлэнэ. Нүүр хуудсанд юу ч
      харуулах шаардлагагүй тул ажлаа эхлэхдээ энэ index Route-ийг устгаж болно.
    </Typography>
  );
}

/**
 * ICSI301 Төсөл 5-ын фото хуваалцах апп.
 *
 * React Router-ийн замууд (гүн холбоос, deep linking):
 *    /                -> Welcome
 *    /users           -> UserList
 *    /users/:userId   -> UserDetail
 *    /photos/:userId  -> UserPhotos
 */
function PhotoShare() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<PhotoShareLayout />}>
          <Route index element={<Welcome />} />
          <Route path="users" element={<UserList />} />
          <Route path="users/:userId" element={<UserDetail />} />
          <Route path="photos/:userId" element={<UserPhotos />} />
        </Route>
      </Routes>
    </BrowserRouter>
  );
}

export default PhotoShare;
