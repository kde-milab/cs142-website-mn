import { AppBar, Toolbar, Typography } from '@mui/material';

import './TopBar.css';

/**
 * ICSI301 Төсөл 5-ын TopBar компонент.
 *
 * TopBar нь <Routes>-ээс гадна (PhotoShareLayout дотор) рендерлэгддэг тул
 * useParams() hook-оор замын параметрийг шууд авч чадахгүй. Үндсэн хэсэгт
 * юу харагдаж байгааг мэдэхийн тулд React Router-ийн useLocation() эсвэл
 * useMatch('/users/:userId') зэрэг hook-ийг ашиглаж болно.
 */
function TopBar() {
  return (
    <AppBar className="icsi301-topbar-appBar" position="absolute">
      <Toolbar>
        <Typography variant="h5" color="inherit">
          Энэ бол TopBar компонент
        </Typography>
      </Toolbar>
    </AppBar>
  );
}

export default TopBar;
