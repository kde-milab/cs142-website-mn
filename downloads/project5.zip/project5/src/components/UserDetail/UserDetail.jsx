import { useParams } from 'react-router';
import { Typography } from '@mui/material';

import icsi301models from '../../modelData/photoApp';
import './UserDetail.css';

/**
 * ICSI301 Төсөл 5-ын UserDetail компонент.
 */
function UserDetail() {
  // React Router нь URL-ийн /users/:userId хэсгээс userId параметрийг
  // ялгаж өгнө. Үүнийг useParams() hook-оор уншина.
  const { userId } = useParams();
  console.log('icsi301models.userModel(userId)', icsi301models.userModel(userId));

  return (
    <Typography variant="body1">
      Энд фото хуваалцах аппын UserDetail харагдац байх ёстой. Энэ компонентыг
      React Router дууддаг тул замын параметрийг useParams() hook-оор авна.
      Тиймээс энд дараах хэрэглэгчийн дэлгэрэнгүйг харуулна: {userId}.
      Хэрэглэгчийн моделийг icsi301models.userModel(userId) функцээс авч болно.
    </Typography>
  );
}

export default UserDetail;
