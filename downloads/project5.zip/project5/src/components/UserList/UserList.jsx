import {
  Divider,
  List,
  ListItem,
  ListItemText,
  Typography,
} from '@mui/material';

import icsi301models from '../../modelData/photoApp';
import './UserList.css';

/**
 * ICSI301 Төсөл 5-ын UserList компонент.
 */
function UserList() {
  // Модель өгөгдөл: системд бүртгэлтэй бүх хэрэглэгчийн массив.
  const users = icsi301models.userListModel();
  console.log('icsi301models.userListModel()', users);

  return (
    <div>
      <Typography variant="body1">
        Энэ бол цонхны 3/12 хэсгийг эзлэх хэрэглэгчдийн жагсаалт. Хэрэглэгчдийг
        дараах байдлаар харуулахдаа{' '}
        <a href="https://mui.com/material-ui/react-list/">List</a> болон{' '}
        <a href="https://mui.com/material-ui/react-divider/">Divider</a>{' '}
        компонентыг ашиглаж болно:
      </Typography>
      <List component="nav">
        <ListItem>
          <ListItemText primary="Мөр #1" />
        </ListItem>
        <Divider />
        <ListItem>
          <ListItemText primary="Мөр #2" />
        </ListItem>
        <Divider />
        <ListItem>
          <ListItemText primary="Мөр #3" />
        </ListItem>
        <Divider />
      </List>
      <Typography variant="body1">
        Модель өгөгдлийг icsi301models.userListModel() функцээс авна.
      </Typography>
    </div>
  );
}

export default UserList;
