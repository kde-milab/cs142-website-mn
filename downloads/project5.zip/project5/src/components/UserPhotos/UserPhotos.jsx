import { useParams } from 'react-router';
import { Typography } from '@mui/material';

import icsi301models from '../../modelData/photoApp';
import './UserPhotos.css';

/**
 * ICSI301 Төсөл 5-ын UserPhotos компонент.
 */
function UserPhotos() {
  // URL-ийн /photos/:userId хэсгээс userId параметрийг уншина.
  const { userId } = useParams();

  return (
    <Typography variant="body1" component="div">
      Энд фото хуваалцах аппын UserPhotos харагдац байх ёстой. Энэ компонентыг
      React Router дууддаг тул замын параметрийг useParams() hook-оор авна.
      Тиймээс энд дараах хэрэглэгчийн зургуудыг харуулна: {userId}.
      Хэрэглэгчийн зургийн моделийг icsi301models.photoOfUserModel(userId)
      функцээс авч болно:
      <Typography
        variant="caption"
        component="pre"
        sx={{ whiteSpace: 'pre-wrap' }}
      >
        {JSON.stringify(icsi301models.photoOfUserModel(userId), null, 2)}
      </Typography>
    </Typography>
  );
}

export default UserPhotos;
