# ICSI301 Төсөл 5-ын модель өгөгдөл

Даалгавар 1-ийн хувьд модель өгөгдлийг ЖаваСкрипт модуль (ES module) болгон бэлдсэн. Бүх модель `icsi301models` нэртэй объектод цуглардаг.

* `icsi301models.userListModel()` - Бүх хэрэглэгчийн массив.
* `icsi301models.userModel(userId)` - Нэг хэрэглэгчийн объект (олдохгүй бол `null`).
* `icsi301models.photoOfUserModel(userId)` - Хэрэглэгчийн зургуудын массив (сэтгэгдлүүдийн хамт).
* `icsi301models.schemaInfo()` - Туршилтын хуурмаг схемийн объект.

React компонент дотроос импортлож хандана. Жишээ нь, `src/components/UserList/UserList.jsx` файлд:

    import icsi301models from '../../modelData/photoApp';

    icsi301models.userListModel()

Зургийн файлууд `public/images` хавтаст байгаа бөгөөд хөтчөөс `/images/<file_name>` замаар хандана.

Даалгавар 2-т `webServer.js` энэ модулийг импортолж, өгөгдлийг HTTP-ээр (`/user/list`, `/user/:id`, `/photosOfUser/:id`, `/test/info`) өгнө. Даалгавар 2-ыг хийсний дараа компонентууд энэ модулийг шууд импортлох ёсгүй.
