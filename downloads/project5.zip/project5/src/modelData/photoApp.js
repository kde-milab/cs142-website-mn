/**
 * ICSI301 Төсөл 5 - фото хуваалцах сайтын модель өгөгдөл.
 * Энэ модуль icsi301models нэртэй объектыг экспортлох бөгөөд дараах функцуудтай:
 *
 * icsi301models.userListModel() - Системийн бүх хэрэглэгчийн жагсаалтыг
 * буцаана. Жагсаалт нь дараах шинжтэй объектуудын массив:
 *   _id (string)         - Хэрэглэгчийн ID.
 *   first_name (string)  - Хэрэглэгчийн өөрийн нэр.
 *   last_name (string)   - Хэрэглэгчийн овог (эцэг/эхийн нэр).
 *   location (string)    - Хэрэглэгчийн байршил.
 *   description (string) - Хэрэглэгчийн тухай товч тайлбар.
 *   occupation (string)  - Хэрэглэгчийн ажил мэргэжил.
 *
 * icsi301models.userModel(userId) - Заасан хэрэглэгчийн мэдээллийг буцаана.
 * Хэрэглэгчийн ID-аар (userId) дуудахад дээрхтэй ижил шинжтэй нэг объект
 * буцаана. Ийм хэрэглэгч байхгүй бол null буцаана.
 *
 * icsi301models.photoOfUserModel(userId) - Заасан хэрэглэгчийн зургуудыг
 * буцаана. Хэрэглэгчийн ID-аар (userId) дуудахад дараах шинжтэй объектуудын
 * массив буцаана:
 *   _id (string)         - Зургийн ID.
 *   date_time (date)     - Зургийг авсан огноо, цаг (ISO формат).
 *   file_name (string)   - images хавтас доторх зургийн файлын нэр.
 *   user_id (string)     - Зургийн эзэн хэрэглэгчийн ID.
 *   comments ([objects]) - Сэтгэгдлүүдийн массив. Сэтгэгдэл бүр дараах шинжтэй:
 *       _id (string)       - Сэтгэгдлийн ID.
 *       date_time (date)   - Сэтгэгдэл бичсэн огноо (ISO формат).
 *       comment (string)   - Сэтгэгдлийн бичвэр.
 *       user: (object)     - Сэтгэгдэл бичсэн хэрэглэгч.
 *       photo_id: (string) - Сэтгэгдэл харьяалагдах зургийн ID.
 *
 * icsi301models.schemaInfo() - Хуурмаг схемийн туршилтын мэдээллийг буцаана.
 * Дараах шинжтэй объект буцаана:
 *   _id (string)           - Схемийн ID.
 *   __v (number)           - Хувилбарын дугаар.
 *   load_date_time (date)  - Схемийг үүсгэсэн огноо (ISO формат).
 *
 * Хэрхэн хандах тухай README.md файлаас үзнэ үү.
 */

// Туршилтын хуурмаг схем.
const schemaInfo = {
  load_date_time: 'Fri Apr 29 2016 01:45:15 GMT-0700 (PDT)',
  __v: 0,
  _id: '57231f1a30e4351f4e9f4bf6',
};

// Анхны хэрэглэгчид.
const tb = {
  _id: '57231f1a30e4351f4e9f4bd7',
  first_name: 'Тэмүүлэн',
  last_name: 'Батболд',
  location: 'Дархан',
  description: 'Машиндаа үлдэх ёстой байж.',
  occupation: 'Математикч',
};
const ag = {
  _id: '57231f1a30e4351f4e9f4bd8',
  first_name: 'Бат-Эрдэнэ',
  last_name: 'Ганзориг',
  location: 'Буянт-Ухаа',
  description: '6-р зэрэглэлтэй. Нисгэгч.',
  occupation: 'Офицер',
};
const te = {
  _id: '57231f1a30e4351f4e9f4bd9',
  first_name: 'Тэлмүүн',
  last_name: 'Энхбаяр',
  location: 'Хөвсгөл',
  description:
    'Гэр минь ард, ертөнц урд... ' +
    'Алхах зам олон бий. Сүүдэр дундуур, шөнийн хязгаар хүртэл, ' +
    'од бүхэн гэрэлтэх хүртэл... Манан, сүүдэр, үүл, бүрэнхий, ' +
    'бүгд бүдгэрнэ... бүгд... бүдгэрнэ... ',
  occupation: 'Мэргэшсэн жолооч',
};
const mb = {
  _id: '57231f1a30e4351f4e9f4bda',
  first_name: 'Мишээл',
  last_name: 'Баярсайхан',
  location: 'Говь-Алтай',
  description: 'Энд ирсэндээ их баяртай байна!',
  occupation: 'Нийгмийн ажилтан',
};
const hm = {
  _id: '57231f1a30e4351f4e9f4bdb',
  first_name: 'Хулан',
  last_name: 'Мөнхжаргал',
  location: 'Эрдэнэт',
  description: 'Шулам',
  occupation: 'Хяналтын байцаагч',
};
const eg = {
  _id: '57231f1a30e4351f4e9f4bdc',
  first_name: 'Энхжин',
  last_name: 'Ганбаатар',
  location: 'МУИС, Улаанбаатар',
  description: '<i>ICSI301!</i>',
  occupation: 'Профессор',
};

const users = [tb, ag, te, mb, hm, eg];

// Анхны зургууд.
const photo1 = {
  _id: '57231f1a30e4351f4e9f4bdd',
  date_time: '2012-08-30 10:44:23',
  file_name: 'ouster.jpg',
  user_id: eg._id,
};
const photo2 = {
  _id: '57231f1a30e4351f4e9f4bde',
  date_time: '2009-09-13 20:00:00',
  file_name: 'malcolm2.jpg',
  user_id: tb._id,
};
const photo3 = {
  _id: '57231f1a30e4351f4e9f4bdf',
  date_time: '2009-09-13 20:05:03',
  file_name: 'malcolm1.jpg',
  user_id: tb._id,
};
const photo4 = {
  _id: '57231f1a30e4351f4e9f4be0',
  date_time: '2013-11-18 18:02:00',
  file_name: 'ripley1.jpg',
  user_id: ag._id,
};
const photo5 = {
  _id: '57231f1a30e4351f4e9f4be1',
  date_time: '2013-09-20 17:30:00',
  file_name: 'ripley2.jpg',
  user_id: ag._id,
};
const photo6 = {
  _id: '57231f1a30e4351f4e9f4be2',
  date_time: '2009-07-10 16:02:49',
  file_name: 'kenobi1.jpg',
  user_id: mb._id,
};
const photo7 = {
  _id: '57231f1a30e4351f4e9f4be3',
  date_time: '2010-03-18 23:48:00',
  file_name: 'kenobi2.jpg',
  user_id: mb._id,
};
const photo8 = {
  _id: '57231f1a30e4351f4e9f4be4',
  date_time: '2010-08-30 14:26:00',
  file_name: 'kenobi3.jpg',
  user_id: mb._id,
};
const photo9 = {
  _id: '57231f1a30e4351f4e9f4be5',
  date_time: '2013-12-03 09:02:00',
  file_name: 'took1.jpg',
  user_id: te._id,
};
const photo10 = {
  _id: '57231f1a30e4351f4e9f4be6',
  date_time: '2013-12-03 09:03:00',
  file_name: 'took2.jpg',
  user_id: te._id,
};
const photo11 = {
  _id: '57231f1a30e4351f4e9f4be7',
  date_time: '2013-09-04 09:16:32',
  file_name: 'ludgate1.jpg',
  user_id: hm._id,
};
const photo12 = {
  _id: '57231f1a30e4351f4e9f4be8',
  date_time: '2008-10-16 17:12:28',
  file_name: 'kenobi4.jpg',
  user_id: mb._id,
};

const photos = [
  photo1,
  photo2,
  photo3,
  photo4,
  photo5,
  photo6,
  photo7,
  photo8,
  photo9,
  photo10,
  photo11,
  photo12,
];

// Анхны сэтгэгдлүүд.
const comment1 = {
  _id: '57231f1a30e4351f4e9f4be9',
  date_time: '2012-09-02 14:01:00',
  comment:
    'Шинэ програмчлалын хэл сурна гэдэг хэцүү юм аа... ' +
    '</div>-ээ мартчихад амархан!',
  user: eg,
  photo_id: photo1._id,
};

const comment2 = {
  _id: '57231f1a30e4351f4e9f4bea',
  date_time: '2013-09-06 14:02:00',
  comment:
    'Энэ бол арай урт бичвэртэй өөр нэг сэтгэгдэл; ' +
    'бичвэр хангалттай урт болоход мөрөөс мөрөнд ' +
    'зөв шилжиж байна уу?',
  user: eg,
  photo_id: photo1._id,
};

const comment3 = {
  _id: '57231f1a30e4351f4e9f4beb',
  date_time: '2013-09-08 14:06:00',
  comment:
    'Хэрэв энэ бичвэрийг <b>тод</b> үсгээр харж байгаа бол ' +
    'HTML escape зөв ажиллахгүй байна гэсэн үг.',
  user: eg,
  photo_id: photo1._id,
};

const comment4 = {
  _id: '57231f1a30e4351f4e9f4bec',
  date_time: '2009-09-14 18:07:00',
  comment:
    'Хувьслын түүх бидэнд нэг л зүйлийг заасан бол тэр нь амьдралыг ' +
    'хашиж хориглох боломжгүй гэдэг. Амьдрал чөлөөлөгдөж, шинэ нутаг ' +
    'руу тэлж, хаалт саадыг нэвтлэн гардаг, өвдөлттэй, магадгүй бүр ' +
    'аюултай ч гэсэн, гэхдээ... за, ийм л байна. Амьдрал гарцаа олдог.',
  user: tb,
  photo_id: photo2._id,
};

const comment5 = {
  _id: '57231f1a30e4351f4e9f4bed',
  date_time: '2013-11-28 17:45:13',
  comment:
    'Аяллаасаа ирлээ. Намайг байхгүй байхад хүмүүсийн IQ... ' +
    'огцом унаад байсан уу?',
  user: ag,
  photo_id: photo5._id,
};

const comment6 = {
  _id: '57231f1a30e4351f4e9f4bee',
  date_time: '2013-11-02 14:07:00',
  comment:
    'Хөөе Мишээл, гоё байна аа. Хаягдал эд ангиар хийсэн ' +
    'техникүүд чинь үнэхээр гоё юм, зөвлөгөө өгөөч?',
  user: ag,
  photo_id: photo7._id,
};

const comment7 = {
  _id: '57231f1a30e4351f4e9f4bef',
  date_time: '2013-11-02 14:09:15',
  comment:
    'Мэдээж! Чиний бүтээлүүдэд үнэхээр дуртай! Одоохондоо аялалд ' +
    'яваа, буцаж ирээд заавал уулзъя! :)',
  user: mb,
  photo_id: photo7._id,
};

const comment8 = {
  _id: '57231f1a30e4351f4e9f4bf0',
  date_time: '2010-09-06 13:59:33',
  comment:
    'Өнөөдөр шинэ найзтай боллоо! За яахав, ядаж араас минь ' +
    'гэр хүртэл дагаад ирсэн.',
  user: mb,
  photo_id: photo8._id,
};

const comment9 = {
  _id: '57231f1a30e4351f4e9f4bf1',
  date_time: '2008-10-16 18:04:55',
  comment:
    'Энэ хөөрхөнгүйгээр би хаашаа ч хүрэхгүй! Хаягдал эд ангиар ' +
    'гараараа бүтнээр нь угсарсан ч, ямар ч шинэ үйлдвэрийн ' +
    'хогноос дутахгүй хурдалдаг.',
  user: mb,
  photo_id: photo12._id,
};

const comment10 = {
  _id: '57231f1a30e4351f4e9f4bf2',
  date_time: '2013-12-04 13:12:00',
  comment: 'Хоёр дахь өглөөний цайны тухай сонсож байгаагүй гэж үү?',
  user: te,
  photo_id: photo10._id,
};

const comment11 = {
  _id: '57231f1a30e4351f4e9f4bf3',
  date_time: '2013-09-04 10:14:32',
  comment:
    'Үзэсгэлэнтэй хэрнээ хүйтэн, хөндий. Ганцаараа явдаг. ' +
    'Дуулгавартай биш, хааяа л хамтран ажиллахаар шийддэг. ',
  user: hm,
  photo_id: photo11._id,
};

const comment12 = {
  _id: '57231f1a30e4351f4e9f4bf4',
  date_time: '2016-01-04 2:00:01',
  comment: 'Чи аль нь вэ?',
  user: hm,
  photo_id: photo9._id,
};

const comment13 = {
  _id: '57231f1a30e4351f4e9f4bf5',
  date_time: '2016-01-04 2:04:01',
  comment: 'Өндөр нь.',
  user: te,
  photo_id: photo9._id,
};

const comments = [
  comment1,
  comment2,
  comment3,
  comment4,
  comment5,
  comment6,
  comment7,
  comment8,
  comment9,
  comment10,
  comment11,
  comment12,
  comment13,
];

// Сэтгэгдэл бүрийг харьяалагдах зургийнх нь comments массивт нэмнэ.
comments.forEach((comment) => {
  // Зөвхөн нэг зураг тохирно.
  const photo = photos.find((p) => p._id === comment.photo_id);
  if (!photo.comments) {
    photo.comments = [];
  }
  photo.comments.push(comment);
});

function userListModel() {
  return users;
}

function userModel(userId) {
  return users.find((user) => user._id === userId) ?? null;
}

function photoOfUserModel(userId) {
  return photos.filter((photo) => photo.user_id === userId);
}

function schemaModel() {
  return schemaInfo;
}

const icsi301models = {
  userListModel,
  userModel,
  photoOfUserModel,
  schemaInfo: schemaModel,
};

export default icsi301models;
