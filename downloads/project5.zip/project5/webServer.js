/**
 * ICSI301 Төсөл 5-ын энгийн Node.js веб сервер. Хоёр үүрэгтэй:
 *
 *  1. npm run build (эсвэл npm run build:w) командаар үүсгэсэн dist/ хавтас
 *     доторх фото хуваалцах аппыг веб хөтчид үйлчилнэ.
 *  2. Модель өгөгдлийг JSON хэлбэрээр өгөх API (Даалгавар 2-т хэрэглэнэ).
 *
 * Серверийг асаахдаа:
 *    npm start        (эсвэл node webServer.js)
 *
 * Анхааруулга: localhost:3000-д холбогдож чадах хэн ч dist/ хавтас доторх
 * файлуудыг татаж авах боломжтой.
 */

import { existsSync } from 'node:fs';
import { join } from 'node:path';
import express from 'express';

import icsi301models from './src/modelData/photoApp.js';

const portno = 3000; // Ашиглах портын дугаар
const distDir = join(import.meta.dirname, 'dist');

const app = express();

/**
 * URL /test/:p1 - Туршилтын зам. /test/info нь схемийн мэдээллийг буцаана.
 */
app.get('/test/:p1', (request, response) => {
  // Express нь URL-ийн ":p1" хэсгийг ялгаж request.params объектод өгнө.
  const param = request.params.p1;
  console.log('/test дуудагдлаа, param1 = ', param);
  if (param !== 'info') {
    console.error('Ийм параметрт хийх зүйл алга: ', param);
    response.status(400).send('Олдсонгүй');
    return;
  }

  const info = icsi301models.schemaInfo();

  // SchemaInfo объект олдоогүй бол энэ нь серверийн дотоод алдаа.
  if (!info) {
    response.status(500).send('SchemaInfo алга');
    return;
  }
  response.status(200).send(info);
});

/**
 * URL /user/list - Бүх хэрэглэгчийн объектыг буцаана.
 */
app.get('/user/list', (request, response) => {
  response.status(200).send(icsi301models.userListModel());
});

/**
 * URL /user/:id - id-тай хэрэглэгчийн мэдээллийг буцаана.
 */
app.get('/user/:id', (request, response) => {
  const id = request.params.id;
  const user = icsi301models.userModel(id);
  if (user === null) {
    console.log('_id:' + id + ' хэрэглэгч олдсонгүй.');
    response.status(400).send('Олдсонгүй');
    return;
  }
  response.status(200).send(user);
});

/**
 * URL /photosOfUser/:id - id-тай хэрэглэгчийн зургуудыг буцаана.
 */
app.get('/photosOfUser/:id', (request, response) => {
  const id = request.params.id;
  const photos = icsi301models.photoOfUserModel(id);
  if (photos.length === 0) {
    console.log('_id:' + id + ' хэрэглэгчийн зураг олдсонгүй.');
    response.status(400).send('Олдсонгүй');
    return;
  }
  response.status(200).send(photos);
});

// dist/ доторх файлуудыг (index.html, JS багц, зураг) express.static
// (https://expressjs.com/en/starter/static-files.html) модуль үйлчилнэ.
app.use(express.static(distDir));

// Гүн холбоос (deep linking): BrowserRouter нь /users/:userId гэх мэт URL
// ашигладаг. Хөтчийг сэргээх (refresh) үед ийм URL серверт ирэх тул дээрх
// замуудын алинд нь ч тохироогүй GET хүсэлтэд аппын index.html-ийг буцаана.
// Ингэснээр React Router URL-ийг уншиж зөв харагдацыг рендерлэнэ.
app.use((request, response, next) => {
  if (request.method !== 'GET') {
    next();
    return;
  }
  response.sendFile(join(distDir, 'index.html'));
});

const server = app.listen(portno, () => {
  const port = server.address().port;
  console.log('http://localhost:' + port + ' хаягаар ' + distDir + ' хавтсыг үйлчилж байна');
  if (!existsSync(distDir)) {
    console.log('dist/ хавтас алга. Эхлээд npm run build (эсвэл npm run build:w) командыг ажиллуулна уу.');
  }
});
