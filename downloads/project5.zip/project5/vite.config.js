import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

// Vite-ийн тохиргоо: https://vite.dev/config/
//
// npm run build (эсвэл npm run build:w) командаар index.html болон src/ доторх
// бүх JSX файлыг багцалж dist/ хавтас дотор үүсгэнэ. public/ хавтаст байгаа
// файлууд (жишээ нь, public/images/*.jpg) dist/ руу өөрчлөлтгүй хуулагдана.
// Үүсгэсэн dist/ хавтсыг webServer.js веб хөтчид үйлчилнэ.
export default defineConfig({
  plugins: [react()],
  build: {
    // Хөтчийн DevTools дээр эх JSX кодоо харж, алдаа хайхад хэрэгтэй.
    sourcemap: true,
    // npm run build:w (--watch) горимын тохиргоо. Анхдагчаар node_modules ч
    // хянагддаг тул Dropbox, OneDrive зэрэг sync хийдэг хавтаст байхад тэдгээрийн
    // файлд хүрэх бүрт дахин дахин build хийгдэнэ. Иймд зөвхөн өөрийн кодыг хянана.
    watch: {
      exclude: ['node_modules/**', 'dist/**'],
      // Олон файл зэрэг өөрчлөгдөхөд нэг л удаа build хийх хүлээлт (ms).
      buildDelay: 300,
    },
  },
});
