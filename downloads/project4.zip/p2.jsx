import React from "react";
import ReactDOM from "react-dom";

import States from "./components/States";

ReactDOM.render(<States />, document.getElementById("reactapp"));
