import { StrictMode } from 'react';
import { createRoot } from 'react-dom/client';
import './styles/main.css';

import Example from './components/Example/Example';

// getting-started.html доторх id="reactapp" div дээр React-ийн root үүсгээд
// Example компонентийг түүн дотор рендерлэнэ.
// StrictMode нь хөгжүүлэлтийн горимд алдааг эрт илрүүлэхэд тусалдаг.
const root = createRoot(document.getElementById('reactapp'));
root.render(
  <StrictMode>
    <Example />
  </StrictMode>
);
