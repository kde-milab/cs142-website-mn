import { StrictMode } from 'react';
import { createRoot } from 'react-dom/client';
import './styles/main.css';

import CitiesProvinces from './components/CitiesProvinces/CitiesProvinces';

const root = createRoot(document.getElementById('reactapp'));
root.render(
  <StrictMode>
    <CitiesProvinces />
  </StrictMode>
);
