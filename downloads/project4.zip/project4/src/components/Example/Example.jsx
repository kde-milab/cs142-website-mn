import { useState, useEffect } from 'react';
import icsi301models from '../../modelData';
import './Example.css';

/**
 * Энэ компонент код харуулдаг тул https://prismjs.com/ кодын өнгөлөгчийг
 * ашиглана. Кодын блокийг className="language-jsx" гэж тэмдэглэснээр өнгөлнө.
 */
import Prism from 'prismjs';
import 'prismjs/components/prism-jsx.js';
import 'prismjs/themes/prism.css';

/**
 * JSX-ийг ЖаваСкриптийн хувьсагчид онооход ердийн ЖаваСкриптийн удирдлагын
 * бүтэц (if, for) ашиглаж болдгийг харуулах туслах функц.
 */
function outOfBandJSX(option) {
  let optionJSX;
  const listItems = [];
  if (option) {
    optionJSX = <div>Сонголт үнэн (true) байлаа</div>;
  } else {
    optionJSX = <div>Сонголт худал (false) байлаа</div>;
  }
  for (let i = 0; i < 3; i++) {
    listItems.push(<li key={i}>Жагсаалтын мөр {i}</li>);
  }
  const retVal = (
    <div>
      {optionJSX}
      <ul>{listItems}</ul>
    </div>
  );

  return retVal;
}

/**
 * React компонент бол props-ийг аргумент болгон авч JSX буцаадаг энгийн
 * ЖаваСкрипт функц юм. Класс, render() метод, this хэрэггүй.
 */
function Example() {
  // useState Hook нь компонентод төлөв (state) нэмнэ. Анхны утга нь
  // аргументаар өгсөн утга бөгөөд [одоогийн утга, шинэчлэх функц] гэсэн хос
  // буцаана. Нэрийн анхны утгыг модель өгөгдлөөс уншина.
  const [name] = useState(icsi301models.exampleModel().name);
  const [counter, setCounter] = useState(0);
  const [inputValue, setInputValue] = useState('');
  const [buttonWasClicked, setButtonWasClicked] = useState('');

  // useEffect Hook нь React DOM-ийг шинэчилсний дараа ажилладаг. [] гэсэн
  // dependency жагсаалт нь компонент анх нэмэгдсэний (mount) дараа нэг удаа
  // ажиллана гэсэн үг. Буцаасан функц (cleanup) нь компонент хасагдахад
  // (unmount) ажиллана.
  useEffect(() => {
    // Төлөв шинэчлэгддэгийг харуулахын тулд counter-ийг 2 секунд тутамд
    // нэмэгдүүлдэг функцийг тодорхойлж, setInterval-аар дуудуулна. Өмнөх
    // утгаас хамаарч шинэчлэхдээ функц дамжуулна: (prev) => prev + 1
    const counterIncrFunc = () => setCounter((prev) => prev + 1);
    const timerID = setInterval(counterIncrFunc, 2 * 1000);

    // Компонент хасагдахад таймерыг зогсооно. Үгүй бол хасагдсан компонентын
    // төлөвийг шинэчлэх гэж оролдоно.
    return () => clearInterval(timerID);
  }, []);

  // Кодын блокуудыг өнгөлөх.
  useEffect(() => {
    Prism.highlightAll();
  }, []);

  // Оролтын талбарт бичих бүрт дуудагдах функц.
  function handleChange(event) {
    setInputValue(event.target.value);
  }

  // Товч дарахад дуудагдах функц.
  function handleButtonClick(buttonName) {
    setButtonWasClicked(buttonName);
  }

  return (
    <div className="container Example">
      <h1>ICSI301 Төсөл 4 React-ийн жишээ</h1>

      <div className="motto-update">
        {/* Даалгавар 1-ийн уриа үгийг дэлгэцлэх, шинэчлэх хэсгийг энд бичнэ */}
      </div>

      <p>
        Энэ харагдац бол <span className="icsi301-code-name">Example</span>{' '}
        нэртэй{' '}
        <a
          href="https://react.dev/learn/your-first-component"
          target="_blank"
          rel="noopener noreferrer"
        >
          React компонентийн
        </a>{' '}
        жишээ. Энэ нь <code>src/components/Example/Example.jsx</code> файлд
        байрладаг. Энэ нь <span className="icsi301-code-name">Example</span>{' '}
        нэртэй энгийн ЖаваСкрипт функц бөгөөд HTML-тэй төстэй зүйл буцаадаг.
        Класс ч, <code>render()</code> метод ч хэрэггүй: функцийн буцаасан утга
        нь компонентын харагдац болно.
      </p>
      <p>
        Энэ нь үнэндээ{' '}
        <a
          href="https://react.dev/learn/writing-markup-with-jsx"
          target="_blank"
          rel="noopener noreferrer"
        >
          JSX
        </a>{' '}
        гэж нэрлэгдэх хэлээр бичигдсэн. Vite багаж JSX-ийг ердийн ЖаваСкрипт
        болгон хөрвүүлнэ. Хөрвүүлсэн ЖаваСкрипт нь React-ийн{' '}
        <code>jsx()</code> функцийн дуудлагууд байдаг (React 17-оос өмнө{' '}
        <a
          href="https://react.dev/reference/react/createElement"
          target="_blank"
          rel="noopener noreferrer"
        >
          createElement
        </a>{' '}
        байсан). Ингэснээр бид компонентын рендерлэх зүйлийг HTML шиг
        харагдах бичлэгээр тодорхойлж чадна.
      </p>
      <p>
        JSX нь HTML-тэй төстэй боловч HTML биш. Зарим ялгаа нь ЖаваСкрипт дотор
        бичигддэгтэй холбоотой. Жишээ нь, <code>class=</code> гэхийн оронд{' '}
        <code>className=</code> гэж бичнэ (class бол ЖаваСкриптийн түлхүүр үг).
        JSX-ийн шинжүүд camelCase хэлбэртэй байдаг (жишээ нь,{' '}
        <code>onChange</code>), харин <code>aria-label</code>,{' '}
        <code>data-id</code> зураасаа хадгална. JSX-ийн тагийн агуулга
        функцийн аргумент болж хувирдаг тул доор харуулсан шиг зарим
        хязгаарлалт бий.
      </p>

      <h3>Загварын орлуулга (template substitution)</h3>

      <p>
        JSX нь угалзан хаалт доторх текстийг (жишээ нь,{' '}
        <code>{'{JavaScriptExpression}'}</code>) загвар гэж үздэг. Хаалт доторх
        ЖаваСкрипт илэрхийллийг тухайн функцийн хүрээнд үнэлж, гарсан утгаар
        нь орлуулна. Илэрхийлэл нь тэмдэгт мөр, тоо эсвэл JSX илэрхийлэл байж
        болно. Ингэснээр компонентын харагдацыг загварчилсан HTML-ээр
        тодорхойлж болно.
      </p>

      <p>
        Example компонент <code>name</code> төлөвийн хувьсагчийн анхны утгыг
        модель өгөгдлөөс авдаг (<code>Example.jsx</code> доторх{' '}
        <code>useState(icsi301models.exampleModel().name)</code>-ийг үзээрэй).
        Түүний утга нь &ldquo;{name}&rdquo; тул:
      </p>
      <pre className="icsi301-example-code">
        <code className="language-jsx">
          {`<p>Миний нэр "{name}".</p>`}
        </code>
      </pre>
      <p>дараах байдлаар рендерлэгдэнэ:</p>
      <p className="icsi301-example-output">Миний нэр &ldquo;{name}&rdquo;.</p>

      <h3>ЖаваСкриптээс HTML рүү чиглэсэн нэг чиглэлт холболт (one-way binding)</h3>

      <p>
        Төлөвийн утга өөрчлөгдөхөд React компонентын функцийг дахин дуудаж,
        JSX загварыг шинэчилнэ. Жишээ нь, <code>{'{counter}'}</code> код нь
        Example компонентын <code>counter</code> төлөвийг дэлгэцлэнэ.
        Компонент <code>useEffect</code> дотор таймер тохируулж, 2 секунд тутамд{' '}
        <code>setCounter</code>-ийг дуудна. Тоолуурын утга өөрчлөгдөж байгааг
        эндээс харж болно: {counter}.
      </p>
      <pre className="icsi301-example-code">
        <code className="language-jsx">
          {`const [counter, setCounter] = useState(0);

useEffect(() => {
  const timerID = setInterval(() => setCounter((prev) => prev + 1), 2 * 1000);
  return () => clearInterval(timerID); // cleanup: таймерыг зогсооно
}, []); // [] = компонент нэмэгдсэний дараа нэг удаа ажиллана`}
        </code>
      </pre>
      <p>
        Хөгжүүлэлтийн горимд <code>StrictMode</code> нь алдааг илрүүлэхийн тулд
        effect-ийг нэг удаа ажиллуулж, cleanup хийгээд, дахин ажиллуулдаг.
        Тиймээс <code>console.log</code> хоёр удаа хэвлэгдвэл гайхах хэрэггүй.
        Cleanup зөв бичигдсэн бол тоолуур 1-ээр л нэмэгдэнэ.
      </p>

      <h3>Удирдлагын урсгал (control flow)</h3>
      <p>
        Ихэнх загварын хэлүүд нөхцөлт рендерлэлт болон давталтыг дэмждэг. JSX
        ЖаваСкрипт дотор бичигдэж, ЖаваСкрипт рүү хөрвүүлэгддэг тул бид
        удирдлагын урсгалд ЖаваСкриптийн бүтцүүдийг шууд ашиглана.
      </p>
      <p>
        Нэг арга нь JSX хэсгүүдийг ЖаваСкриптийн хувьсагчид онооход ердийн
        ЖаваСкриптийн удирдлагын операторуудыг ашиглах юм. Жишээ нь, дараах
        функц аргументаасаа хамаарч гаргах мөрийг сонгож, for давталтаар массив
        дүүргэнэ. Эдгээр хувьсагчийг функцийн буцаах JSX дотор хэрэглэж болно.
      </p>
      <pre className="icsi301-example-code">
        <code className="language-jsx">
          {`function outOfBandJSX(option) {
  let optionJSX;
  const listItems = [];
  if (option) {
    optionJSX = <div>Сонголт үнэн (true) байлаа</div>;
  } else {
    optionJSX = <div>Сонголт худал (false) байлаа</div>;
  }
  for (let i = 0; i < 3; i++) {
    listItems.push(<li key={i}>Жагсаалтын мөр {i}</li>);
  }
  const retVal = (
    <div>
      {optionJSX}
      <ul>{listItems}</ul>
    </div>
  );

  return retVal;
}`}
        </code>
      </pre>
      <p>
        Энэ функцийг загвар дотроос дуудвал (жишээ нь,{' '}
        <code>{'{outOfBandJSX(true)}'}</code>) дараах байдлаар дэлгэцлэгдэнэ:
      </p>
      <div className="icsi301-example-output">{outOfBandJSX(true)}</div>
      <p>
        Өөр нэг арга нь үйлдлүүдийг угалзан хаалт дотор шууд бичих юм. Угалзан
        хаалт дотор дурын ЖаваСкрипт бичиж болох ч энэ нь утга буцаадаг
        илэрхийлэл байх ёстой. if, for, while зэрэг ЖаваСкриптийн
        удирдлагын командууд утга буцаадаггүй тул{' '}
        <code>{'{if (bool) ... else ...}'}</code> гэх мэт загвар ажиллахгүй.
      </p>
      <p>
        Дараах код нь ЖаваСкриптийн {'"?:"'} оператор болон функциональ
        програмчлалын <code>map</code> функцийг ашиглан дээрхтэй ижил үр дүнг
        гаргана. Эдгээр нь үргэлж утга буцаадаг:
      </p>
      <pre className="icsi301-example-code">
        <code className="language-jsx">
          {`<div>
  {option ? <div>Сонголт үнэн (true) байлаа</div> : <div>Сонголт худал (false) байлаа</div>}
  <ul>
    {[0, 1, 2].map((i) => <li key={i}>Жагсаалтын мөр {i}</li>)}
  </ul>
</div>`}
        </code>
      </pre>
      <p>
        <code>key=</code> шинж нь өгөгдөл өөрчлөгдөхөд React-д жагсаалтыг
        үр ашигтай дахин рендерлэхэд тусална.
      </p>
      <p>
        {'"&&"'} гэх мэт богино тойрогт логик үйлдлээр юу рендерлэхийг удирдаж
        болно. Жишээ нь, доорх оролтын талбарт тэмдэгт бичихэд дараах код хоёр
        догол мөрийн хооронд нэг өгүүлбэр гаргаж ирнэ.
      </p>
      <pre className="icsi301-example-code">
        <code className="language-jsx">
          {`<div>
  <p>Энэ догол мөр болон</p>
  {inputValue && (
    <p>
      Энэ бичвэр inputValue үнэн (truthy) үед гарч ирнэ.
      inputValue === {inputValue}
    </p>
  )}
  <p>... энэ догол мөрийн хооронд доорх талбарт бичихэд нэг догол мөр гарч ирнэ.</p>
</div>`}
        </code>
      </pre>
      <p>Гаралт нь:</p>
      <div className="icsi301-example-output">
        <p>Энэ догол мөр болон</p>
        {inputValue && (
          <p>
            Энэ бичвэр inputValue үнэн (truthy) үед гарч ирнэ. inputValue ===
            {inputValue}
          </p>
        )}
        <p>
          ... энэ догол мөрийн хооронд доорх талбарт бичихэд нэг догол мөр гарч
          ирнэ.
        </p>
      </div>

      <h3>DOM-той төстэй үзэгдлийн функцээр оролт авах</h3>
      <p>
        React-д оролтыг DOM-той төстэй{' '}
        <a
          href="https://react.dev/learn/responding-to-events"
          target="_blank"
          rel="noopener noreferrer"
        >
          үзэгдлийн функцээр (event handler)
        </a>{' '}
        хүлээн авна. Жишээ нь, дараах JSX:
      </p>
      <pre className="icsi301-example-code">
        <code className="language-jsx">
          {`<label htmlFor="inId">Оролтын талбар: </label>
<input id="inId" type="text" value={inputValue} onChange={handleChange} />`}
        </code>
      </pre>
      <p>
        нь <code>inputValue</code> төлөвийн утгыг оролтын талбарт дэлгэцлэх
        бөгөөд (эхэндээ хоосон) талбар өөрчлөгдөх бүрт{' '}
        <code>handleChange</code> функцийг дуудна. Ийм оролтыг ихэвчлэн товч
        эсвэл{' '}
        <a
          href="https://react.dev/reference/react-dom/components/input"
          target="_blank"
          rel="noopener noreferrer"
        >
          форм
        </a>{' '}
        дотор хэрэглэж, хэрэглэгч бичиж дууссанаа мэдэгдэх боломж олгодог.
        HTML-ээс ялгаатай нь <code>onchange=</code> нь <code>onChange=</code>,{' '}
        <code>for=</code> нь <code>htmlFor=</code> болдгийг анхаараарай.
      </p>

      <div className="icsi301-example-output">
        <label htmlFor="inId">Оролтын талбар: </label>
        <input
          id="inId"
          type="text"
          value={inputValue}
          onChange={handleChange}
        />
      </div>
      <p>
        <code>handleChange</code> функц нь DOM элементийн утгаар{' '}
        <code>setInputValue</code>-ийг дуудаж төлөвийг шинэчилнэ. Тиймээс{' '}
        <code>{'{inputValue}'}</code> гэж хандахад &ldquo;{inputValue}&rdquo;
        гэсэн утга гарна. <code>handleChange</code> бол{' '}
        <code>this</code>-гүй энгийн функц тул <code>onChange</code>-д шууд
        дамжуулж болно. (Хуучин класс компонентод методыг дамжуулахад{' '}
        <code>this</code> алдагддаг байсан тул <code>bind(this)</code>{' '}
        хэрэглэх шаардлагатай байсан.)
      </p>
      <p>
        Үзэгдлийн функцэд аргумент дамжуулах бол дараах шиг arrow функц
        ашиглана:
      </p>
      <pre className="icsi301-example-code">
        <code className="language-jsx">
          {`<div className="icsi301-example-output">
  <p>Товч дарахыг шалгах.
    {buttonWasClicked && (
      <span>Сүүлд дарсан товч: {buttonWasClicked}</span>
    )}
  </p>
  <button type="button" onClick={() => handleButtonClick('нэг')}>
    handleButtonClick функцийг "нэг" аргументтай дуудах
  </button>
  <button type="button" onClick={() => handleButtonClick('хоёр')}>
    handleButtonClick функцийг "хоёр" аргументтай дуудах
  </button>
</div>`}
        </code>
      </pre>
      <p>
        Товч дарахад arrow функц дуудагдаж, тэр нь{' '}
        <code>handleButtonClick</code> функцийг заасан аргументтай дуудна.
      </p>
      <div className="icsi301-example-output">
        <p>
          Товч дарахыг шалгах.{' '}
          {buttonWasClicked && (
            <span>Сүүлд дарсан товч: {buttonWasClicked}</span>
          )}
        </p>
        <button type="button" onClick={() => handleButtonClick('нэг')}>
          handleButtonClick функцийг &ldquo;нэг&rdquo; аргументтай дуудах
        </button>
        <button type="button" onClick={() => handleButtonClick('хоёр')}>
          handleButtonClick функцийг &ldquo;хоёр&rdquo; аргументтай дуудах
        </button>
      </div>
    </div>
  );
}

export default Example;
