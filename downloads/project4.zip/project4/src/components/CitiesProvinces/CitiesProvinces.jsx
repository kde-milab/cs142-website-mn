import icsi301models from '../../modelData';
import './CitiesProvinces.css';

/**
 * ICSI301 Төсөл 4, Даалгавар 2-ын CitiesProvinces компонент. Энэ харагдацын
 * модель өгөгдөл (хот, аймгийн нэрс) icsi301models.citiesProvincesModel()
 * функцээс гарна.
 */
function CitiesProvinces() {
  console.log(
    'icsi301models.citiesProvincesModel()',
    icsi301models.citiesProvincesModel()
  );

  return <div>Үүнийг ICSI301 Төсөл 4, Даалгавар 2-ын кодоор солино уу</div>;
}

export default CitiesProvinces;
