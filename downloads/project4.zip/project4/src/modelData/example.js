/*
 * ICSI301 Төсөл 4, Даалгавар 1-ийн модель өгөгдөл. exampleModel функц нь дараах
 * шинжтэй объект буцаана:
 *    name:  Нэр агуулсан тэмдэгт мөр.
 *
 * Хэрхэн хандах тухай README.md файлаас үзнэ үү.
 */
export default function exampleModel() {
  return {
    name: 'Unknown Name',
  };
}
