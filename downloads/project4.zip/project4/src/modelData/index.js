/*
 * ICSI301 Төсөл 4-ийн модель өгөгдөл. Харагдац бүрийн моделийг icsi301models
 * объектын шинж болгон нэг дор цуглуулна. Компонент дотроос:
 *
 *    import icsi301models from '../../modelData';
 *    icsi301models.exampleModel().name
 *
 * гэж хандана.
 */
import exampleModel from './example.js';
import citiesProvincesModel from './citiesProvinces.js';

const icsi301models = {
  exampleModel,
  citiesProvincesModel,
};

export default icsi301models;
