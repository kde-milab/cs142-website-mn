# ICSI301 Төсөл 4-ийн модель өгөгдөл

Бидэнд модель өгөгдлийг татаж авах сервер, өгөгдлийн сан хараахан байхгүй тул модель өгөгдлийг ЖаваСкрипт модуль (ES module) болгон бэлдсэн. Бүх модель `icsi301models` нэртэй объектод цуглардаг.

* `icsi301models.exampleModel()` - Даалгавар 1-ийн Example харагдацын модель.
* `icsi301models.citiesProvincesModel()` - Даалгавар 2-ын хот, аймгийн харагдацын модель.

React компонент дотроос импортлож хандана. Жишээ нь, `src/components/CitiesProvinces/CitiesProvinces.jsx` файлд:

    import icsi301models from '../../modelData';

    icsi301models.citiesProvincesModel()

гэвэл хот, аймгийн нэрсийн массивыг буцаана, тиймээс

    icsi301models.citiesProvincesModel()[0] === 'Улаанбаатар'
