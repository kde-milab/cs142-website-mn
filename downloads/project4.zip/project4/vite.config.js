import { resolve } from 'node:path';
import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

// Vite-ийн тохиргоо: https://vite.dev/config/
//
// Хөгжүүлэлтийн горимд (npm run dev) төслийн үндсэн хавтаст байгаа ямар ч HTML
// хуудсыг (жишээ нь, p4.html) нэмэлт тохиргоогүйгээр шууд дуудаж болно.
// Харин npm run build командаар багц үүсгэхэд олон хуудастай аппын HTML хуудас
// бүрийг доорх input жагсаалтад нэмж өгөх шаардлагатай.
export default defineConfig({
  plugins: [react()],
  build: {
    rollupOptions: {
      input: {
        index: resolve(import.meta.dirname, 'index.html'),
        gettingStarted: resolve(import.meta.dirname, 'getting-started.html'),
        p2: resolve(import.meta.dirname, 'p2.html'),
        // Даалгавар 4, 5-ыг хийхдээ доорх мөрүүдийн комментыг арилгана.
        // p4: resolve(import.meta.dirname, 'p4.html'),
        // p5: resolve(import.meta.dirname, 'p5.html'),
      },
    },
  },
});
